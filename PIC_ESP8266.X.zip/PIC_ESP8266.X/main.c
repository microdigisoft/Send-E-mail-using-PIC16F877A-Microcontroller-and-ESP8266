#define _XTAL_FREQ 20000000
#include <xc.h>
#include "I2C.h"
#include "ESP8266.h"

void main()
{
   
    I2C__Init();
    LCD_Init(0x4E);    // Initialize LCD module with I2C address = 0x4E
    Initialize_ESP8266() ; 
    LCD_Set_Cursor(1,1);
    LCD_Write_String("MicroDigisoft.com");
    LCD_Set_Cursor(2,1);
    LCD_Write_String("ESP5266 with PIC");
    __delay_ms(1500);
    LCD_Clear();
    
    /*Check if the ESP_PIC communication is successful*/
    do
    {
    LCD_Set_Cursor(1,1);
    LCD_Write_String("ESP not found");
    }while (!esp8266_isStarted()); //wait till the ESP send back "OK"
    LCD_Set_Cursor(1,1);
    LCD_Write_String("ESP is connected");
    __delay_ms(1500);
    LCD_Clear();
    /*Yes ESP communication successful*/
    
    /*Put the module in Soft AP  mode*/
    esp8266_mode(2);
    LCD_Set_Cursor(1,1);
    LCD_Write_String("ESP set as AP");
    __delay_ms(1500);
    LCD_Clear();
    /*Module set as AP */
    
    /*Configure the AP name and Password*/
    esp8266_config_softAP("microdigisoft","123456789");
    LCD_Set_Cursor(1,1);
    LCD_Write_String("AP configured");
    __delay_ms(1500);
    /*AP configured*/
    
   
            
    while(1)
    {
        //do nothing 
    }

}