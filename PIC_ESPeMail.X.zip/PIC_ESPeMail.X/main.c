/*
 * File:   main.c
 * Author: Administrator
 *
 * Created on 16 January, 2021, 1:16 PM
 */


#define _XTAL_FREQ 20000000
#include <xc.h>
#include "I2C.h"
#include "ESP8266.h"

void main()
{
    I2C__Init();
    LCD_Init(0x4E);    // Initialize LCD module with I2C address = 0x4E
    Initialize_ESP8266() ; 
    LCD_Set_Cursor(1,1);
    LCD_Write_String("MicroDigisoft.com");
    LCD_Set_Cursor(2,1);
    LCD_Write_String("ESPMail with PIC");
    __delay_ms(1500);
    LCD_Clear();
    
  /*Yes ESP communication successful -Proceed*/
    
    
    /*Put the module in AP+STA*/
    esp8266_mode(3);
    LCD_Set_Cursor(1,1);
    LCD_Write_String("ESP set AP+STA");
    __delay_ms(1500);
    LCD_Clear();
    /*Module set as AP+STA*/
    
    
    /*Connect to a AccesPoint*/
    esp8266_connect("xxxxxx","xxxxxx"); //Enter you WiFi name and password here, here BPAS home is the name and cracksun is the pas
    LCD_Set_Cursor(1,1);
    LCD_Write_String("Connected 2 WIFI"); //Print on LCD for debugging. 
    __delay_ms(1500);
    LCD_Clear();
    /*Connected to WiFi*/
    
    
    
    _esp8266_enale_MUX(); //Enable multiple connections
    _esp8266_create_server(); //Create a server on port 80
    _esp8266_connect_SMPT2GO(); //Establish TCP connection with SMPT2GO
    

    _esp8266_login_mail("xxxjshdhxxxxwjaja=","hdfnxxxxaxxrbj==");
    LCD_Set_Cursor(1,1);
    LCD_Write_String("Login Successful"); //display on LCD for debugging
    __delay_ms(1500);
    LCD_Clear();
    /*End of Login*/
    
    
    _esp8266_mail_sendID("xxxx@gmail.com"); //The sender mail ID
    _esp8266_mail_recID("xxxxx@gmail.com"); //The Receiver mail ID
    
    _esp8266_start_mail();
    _esp8266_mail_subject("Mail-Microdigisoft-ESP8266"); //Enter the subject of your mail
    _esp8266_mail_body("Test Email-Microdigisoft"); //Enter the body of your mail       
    _esp8266_End_mail();
    
    _esp8266_disconnect_SMPT2GO();
    
    
    LCD_Set_Cursor(1,1);
    LCD_Write_String("Mail Sent"); //Print on LCD for debugging
 
            
    while(1)
    {
        //do nothing 
    }

}